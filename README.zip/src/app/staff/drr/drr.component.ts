import { Component } from '@angular/core';

@Component({
  selector: 'app-drr',
  standalone: true,
  imports: [],
  templateUrl: './drr.component.html',
  styleUrl: './drr.component.css'
})
export class DrrComponent {

}
