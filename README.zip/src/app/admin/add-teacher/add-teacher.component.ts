import { Component } from '@angular/core';

@Component({
  selector: 'app-add-teacher',
  standalone: true,
  imports: [],
  templateUrl: './add-teacher.component.html',
  styleUrl: './add-teacher.component.css'
})
export class AddTeacherComponent {

}
